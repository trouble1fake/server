from trouble1 import db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(50), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    twitter = db.Column(db.String(50))
    instagram = db.Column(db.String(50))
    image_file = db.Column(db.String(50))
    
    token = db.Column(db.String(40))

    def __repr__(self):
        return f"User('{self.email}','{self.name}','{self.twitter}','{self.instagram}','{self.image_file}')"