from flask import render_template, render_template_string, url_for, flash, redirect, request, session
from trouble1 import app
from trouble1.forms import accessToken, purchaseform, helpform
from trouble1.functions import createLink, validatelink, welcomeMail, sendRestLink, profile_info
import requests
from werkzeug.utils import secure_filename
from flask_wtf.file import FileField, FileRequired


@app.route("/", )
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/home/<time>/<token>",methods=['GET','POST'])
def home1(time, token):
    email = validatelink(time, token)
    if email == False:
        flash("Invalid Token!", "danger")
        return redirect(url_for('home'))
    return render_template('home.html', email=email, time=time ,token=token, purchasePage=True, home='active')

@app.route("/purchase/<time>/<token>",methods=['GET','POST'])
def purchase(time, token):
    form = purchaseform()
    email = validatelink(time, token)
    if email == False:
        flash("Invalid Token!", "danger")
        return redirect(url_for('home'))
    if form.validate_on_submit():
        flash('Success!','success')
      
    return render_template('purchase.html', form=form, email=email, time=time ,token=token, purchasePage=True, purchase='active')


@app.route("/help/<time>/<token>",methods=['GET','POST'])
def help(time, token):
    email = validatelink(time, token)
    form = helpform()
    if email == False:
        flash("Invalid Token!", "danger")
        return redirect(url_for('home'))
    if form.validate_on_submit():
        f = form.file.data
        filename = secure_filename(f.filename)
        f.save('uploads/' + filename)
        flash("Message Sent, Will Contact you as soon as possible!", "success")
    return render_template('help.html', form=form, email=email, time=time ,token=token)


@app.route("/purchaseLink", methods=['GET','POST'])
def purchaseLink():
    form = accessToken()
    email = request.form.get('email')
    if email:
        if form.validate_on_submit():
            msg = createLink(request.headers.get('X-Forward-Host'), email) 
            flash(msg[0], msg[1])
            return redirect(url_for('home'))
    return render_template('purchaseLink.html', form=form, msg=email)



@app.route("/chat", methods=['GET','POST'])
def chat():
    if request.method == 'POST':
        name = request.form['name']
        programmer = request.form['programmer']
        email = request.form['email'] 
        welcomeMail(name, email)
        
    return render_template('chat.html')




@app.route("/profile/<user_name>", methods=['GET','POST'])
def profile(user_name):
    user_name = user_name.replace("_", " ")
    profile =  profile_info(user_name)
    return render_template('profile.html', profile=profile, nohelpbot=True)



@app.errorhandler(404)
def page_not_found(e):
    return redirect(url_for('home'))

#http://localhost:5000/test?test=fasf&name={{%27%27.__class__.__mro__[1].__subclasses__()[774](%27dir%27,shell=True,stdout=-1).communicate()}}