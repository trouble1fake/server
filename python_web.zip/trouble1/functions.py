import time, random, socket, smtplib, hashlib, urllib.request
from trouble1.models import User
from trouble1 import db
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import render_template_string
from flask_mail import Message
from trouble1 import mail



def profile_info(user_name):
    name = User.query.filter_by(name=user_name).first()
    
    if name:
        return name
    else:
        return False
    
    

def sendRestLink(email, url, valid):  
    user = User.query.filter_by(email=email).first()

    msg = Message('Password Reset Request',
                  sender='noreply@demo.com',
                  recipients=[email])
    
    if valid == False:
        msg.html = f'''Sorry, reset passowrd will not work for you as you are not valid user.
'''
    else:
        msg.html = f'''
    To reset your password <a href=%s>click here</a>, <br>
If you did not make this request then simply ignore this email and no changes will be made.
''' % url
    
    mail.send(msg)


def createLink(host, email):
    now = str(int(time.time()))
    rand = str(random.getrandbits(128))
    m = hashlib.sha1()
    m.update((now + rand).encode())
    token =  m.hexdigest()
    url = "http://" + str(host) + "/purchase/" + now + "/" + rand
    user = User.query.filter_by(email=email).first()
    if user:
        admin = User.query.filter_by(email=email).update(dict(token=token))
        db.session.commit()
        
        try:
            urllib.request.urlopen(url)
        except:
            return "Something went wrong!" , "danger" 
        sendRestLink(email, url,True)
    else:
        sendRestLink(email, False, False)
  #      Addtoken = User(email=email, token=token, name="Alline Hudec", image_file="https://princesspinkygirl.com/wp-content/uploads/2014/12/Square-Profile-Pic.jpg", twitter="AllineHudec0532", instagram="AllineHudec0532")
#        db.session.add(Addtoken)
#        db.session.commit()

    
    
    return "Purchase link has been sent to given email Id", "success"



def validatelink(time, token):
    now = time
    token = token
    m = hashlib.sha1()
    m.update((now + token).encode())
    token =  m.hexdigest()
    user = User.query.filter_by(token=token).first()
    if user:
        return (user.email)
    
    return False


def welcomeMail(name, email):
    name = name.replace("__", " ")
    msg = Message('You\'re in!',
                  sender='noreply@demo.com',
                  recipients=[email])
    mail_content = '''
    <head>
<link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel = "stylesheet" href = "http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
</head>

<div style="margin:20px; color:#ff5270;background-color:#000000" ><div style="margin: 10px">
<center><h1 style="letter-spacing:4px">Welcome To Trouble1 Hacking</h1></center>
<br>
<strong>Hello %s,</strong><br>
Thank you for showing your interest, I hope you will be able hack this lab. You will come across to many application as you keep hacking one by one. This is a real life <b>Red Team lab</b> where you are going to compromise the admin system by hacking and abusing application's features.<br><br>
This lab will give you a real life hacking expirence of a company by only using application. Good luck!
<br><br>
Sincerely,<br>
Raunak Parmar
<br><br><br>
    Contact:
<a href="https://twitter.com/trouble1_raunak"><span class = "fa fa-twitter"></span>trouble1_raunak</a>
</div></div>

''' % name
    msg.html  = render_template_string(mail_content)
    #The mail addresses and password
    mail.send(msg)
    
    
    
