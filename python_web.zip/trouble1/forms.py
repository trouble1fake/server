from flask_wtf import FlaskForm
from wtforms import StringField, FieldList, FormField, PasswordField, SubmitField, BooleanField, Form, IntegerField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, Optional
from wtforms.widgets import TextArea
from flask_wtf.file import FileField, FileRequired, FileAllowed

class accessToken(FlaskForm):

    email = StringField('Email', validators=[DataRequired(), Email()])
   
    submit = SubmitField('Send')
    
    

class purchaseform(FlaskForm):
    category_name = StringField('Category Name')
    product = SelectField(u'Programming Language', choices=[('cpp', 'C++'), ('py', 'Python'), ('js', 'NodeJs')])
    quantity = SelectField(u'Period', choices=[('1 Month'), ('2 Months'), ('3 Months')])
    
    submit = SubmitField('Purchase')
    
    
class helpform(FlaskForm):
    title = StringField(u'Title', validators=[DataRequired()])
    body = StringField(u'Text', widget=TextArea())
    file = FileField()
    submit = SubmitField('Send')
    
    